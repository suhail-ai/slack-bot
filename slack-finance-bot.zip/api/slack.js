import { google } from "googleapis";
import fetch from "node-fetch";
import querystring from "querystring";

/*
  Slack Finance Bot - simple Vercel function
  - Handles Slack URL verification (challenge)
  - Handles slash commands (POST application/x-www-form-urlencoded)
  - Reads two sheets from a single Google Sheet ID:
      'Pending Payments' (range auto)
      'Data for chatbot' (range auto)
  - Replies via response_url (for slash commands) or chat.postMessage (for events)

  ENV (add to Vercel):
    SHEET_ID
    GOOGLE_CLIENT_EMAIL
    GOOGLE_PRIVATE_KEY   (paste with \n replaced by newline OR raw multiline - see README)
    GEMINI_API_KEY       (optional - used if you want AI summaries)
    SLACK_BOT_TOKEN      (xoxb token) - required for event replies
*/

function getPrivateKey() {
  if (!process.env.GOOGLE_PRIVATE_KEY) return null;
  // allow either raw newlines or escaped \n
  return process.env.GOOGLE_PRIVATE_KEY.includes("\\n")
    ? process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, "\n")
    : process.env.GOOGLE_PRIVATE_KEY;
}

async function getSheetsClient() {
  const clientEmail = process.env.GOOGLE_CLIENT_EMAIL;
  const privateKey = getPrivateKey();
  if (!clientEmail || !privateKey) throw new Error("Google service account env missing");

  const auth = new google.auth.GoogleAuth({
    credentials: {
      client_email: clientEmail,
      private_key: privateKey,
    },
    scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
  });
  const client = await auth.getClient();
  return google.sheets({ version: "v4", auth: client });
}

function formatCurrencyCell(v) {
  if (v == null) return "";
  return v;
}

// Reads a range from a named sheet; if not present returns []
async function readSheet(sheetName) {
  const sheets = await getSheetsClient();
  const spreadsheetId = process.env.SHEET_ID;
  if (!spreadsheetId) throw new Error("SHEET_ID missing in env");

  // We'll request a large range to capture rows (A:Z)
  const range = `'${sheetName}'!A2:Z1000`;
  const resp = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range,
    valueRenderOption: "UNFORMATTED_VALUE"
  });
  return resp.data.values || [];
}

async function askGemini(prompt) {
  // optional helper - only used if GEMINI_API_KEY set
  const key = process.env.GEMINI_API_KEY;
  if (!key) return null;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`;
  const body = {
    contents: [{ parts: [{ text: prompt }] }]
  };
  const r = await fetch(url, { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(body) });
  try {
    const j = await r.json();
    return j.contents?.[0]?.parts?.[0]?.text || JSON.stringify(j);
  } catch(e) {
    return null;
  }
}

async function replyToSlackViaResponseUrl(response_url, text) {
  if (!response_url) return;
  await fetch(response_url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text })
  });
}

async function postMessage(channel, text) {
  const token = process.env.SLACK_BOT_TOKEN;
  if (!token) throw new Error("SLACK_BOT_TOKEN missing");
  await fetch("https://slack.com/api/chat.postMessage", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ channel, text })
  });
}

export default async function handler(req, res) {
  try {
    // Slack URL verification
    const contentType = req.headers["content-type"] || "";
    let payload = req.body;

    // If form-encoded (slash command), parse raw body
    if (contentType.includes("application/x-www-form-urlencoded") && typeof req.body === "string") {
      payload = querystring.parse(req.body);
    }

    // If JSON body and a url_verification challenge
    if (payload && payload.type === "url_verification") {
      return res.status(200).send(payload.challenge);
    }

    // Slash command handling (application/x-www-form-urlencoded)
    if (payload && payload.command) {
      // immediate ack to Slack
      res.status(200).json({ response_type: "ephemeral", text: "Processing… (I will post the full result shortly)" });

      // Background processing
      (async () => {
        const text = payload.text || "";
        const response_url = payload.response_url;
        // For simplicity: if text includes "pending" or is empty -> show pending payments
        if (/pending/i.test(text) || text.trim() === "") {
          const rows = await readSheet("Pending Payments");
          if (!rows.length) {
            await replyToSlackViaResponseUrl(response_url, "No pending payments found.");
            return;
          }
          // Build a short summary + table lines (limit to 20)
          const lines = rows.slice(0, 40).map(r => {
            const invoice = r[0] || "(no)";
            const client = r[1] || "";
            const date = r[3] || "";
            const status = r[5] || "";
            const amount = r[6] || "";
            return `• ${client} — ${invoice} — ${status} — ${amount} — ${date}`;
          });
          const summary = `Pending payments: ${rows.length} found. Showing top ${Math.min(rows.length,40)}:`;
          await replyToSlackViaResponseUrl(response_url, `${summary}\n\n${lines.join("\n")}`);
          return;
        }

        if (/cashflow|cash flow|cash/i.test(text)) {
          const rows = await readSheet("Data for chatbot");
          if (!rows.length) {
            await replyToSlackViaResponseUrl(response_url, "No data found for cashflow.");
            return;
          }
          // simple monthly filter: find month names
          const m = text.match(/(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i);
          let filtered = rows;
          if (m) {
            const month = m[0].toLowerCase();
            // assume invoice date in column 2 (index 2)
            filtered = rows.filter(r => {
              const d = String(r[2] || "");
              return d.toLowerCase().includes(month);
            });
          }
          const totalInv = filtered.reduce((s,r)=>s + (Number(String(r[3]).replace(/[^0-9.-]/g,""))||0), 0);
          const totalPaid = filtered.reduce((s,r)=>s + (Number(String(r[4]).replace(/[^0-9.-]/g,""))||0), 0);
          const pending = totalInv - totalPaid;
          const lines = filtered.slice(0,40).map(r=>`• ${r[1] || ''} — ${r[0] || ''} — ${r[3] || ''}`);
          const summary = `Invoiced: ${totalInv.toFixed(2)}, Paid: ${totalPaid.toFixed(2)}, Pending: ${pending.toFixed(2)}. Rows: ${filtered.length}`;
          // optional AI summary
          const ai = await askGemini(`Summarize cashflow: ${summary}`);
          await replyToSlackViaResponseUrl(response_url, `${summary}\n\n${ai ? "AI: "+ai+"\n\n" : ""}${lines.join("\n")}`);
          return;
        }

        // default fallback: echo
        await replyToSlackViaResponseUrl(response_url, `I received your command: "${text}". Try "pending" or "cashflow <month>"`);
      })();

      return;
    }

    // Event subscriptions (app_mention)
    if (payload && payload.event && payload.event.type === "app_mention") {
      // immediate ack
      res.status(200).send("ok");
      const channel = payload.event.channel;
      const text = payload.event.text || "";
      // Process: if pending mention -> post message
      if (/pending/i.test(text)) {
        const rows = await readSheet("Pending Payments");
        const lines = rows.slice(0,20).map(r=>`• ${r[1] || ''} — ${r[0] || ''} — ${r[6] || ''}`);
        const message = lines.length ? `Pending payments:\n${lines.join("\n")}` : "No pending payments.";
        await postMessage(channel, message);
        return;
      }

      if (/cashflow|cash/i.test(text)) {
        const rows = await readSheet("Data for chatbot");
        const totalInv = rows.reduce((s,r)=>s + (Number(String(r[3]).replace(/[^0-9.-]/g,""))||0),0);
        const totalPaid = rows.reduce((s,r)=>s + (Number(String(r[4]).replace(/[^0-9.-]/g,""))||0),0);
        const pending = totalInv - totalPaid;
        const message = `Cashflow summary — Invoiced: ${totalInv.toFixed(2)}, Paid: ${totalPaid.toFixed(2)}, Pending: ${pending.toFixed(2)}.`;
        await postMessage(channel, message);
        return;
      }

      await postMessage(payload.event.channel, "Try: pending or cashflow <month>");
      return;
    }

    // default
    res.status(200).send("ok");
  } catch (err) {
    console.error("Handler error:", err);
    res.status(500).json({ error: String(err && err.message ? err.message : err) });
  }
}
