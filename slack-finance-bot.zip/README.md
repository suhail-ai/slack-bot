# Slack Finance Bot (Vercel)

Files included:
- package.json
- api/slack.js

How to deploy:
1. Create a GitHub repo and push these files (or upload via GitHub web UI).
2. Connect the repo to Vercel (https://vercel.com) and deploy.
3. Add Environment Variables in Vercel (Project → Settings → Environment Variables):
   - SHEET_ID = <your spreadsheet id>
   - GOOGLE_CLIENT_EMAIL = <service account client_email>
   - GOOGLE_PRIVATE_KEY = <private_key>
     - You can paste it either as raw multiline (works), or replace real newlines with \n.
   - SLACK_BOT_TOKEN = <xoxb-...>
   - GEMINI_API_KEY = <optional - for AI summaries>
4. In Slack App (https://api.slack.com/apps), set:
   - Slash Command (e.g. /ai) with Request URL:
     https://<your-vercel-domain>/api/slack
   - Event Subscriptions Request URL set to same endpoint and subscribe to `app_mention`.
   - Bot Token Scopes: chat:write, commands, app_mentions:read
   - Install/Reinstall the app to workspace.
5. Test:
   - In Slack: `/ai pending` or `/ai cashflow november`
   - Or mention bot: @Bot pending

Notes:
- The function replies immediately to slash commands with a small ephemeral message and then posts the full result via response_url.
- Keep your Google Service Account JSON safe. Share the Google Sheet with the service account email.
